
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <a class="p-2 m-2 fa-lg fb-ic ml-0" href="<?php echo e($menu_item->link()); ?>">
        <i class="<?php echo e($menu_item->icon_class); ?> white-text mr-lg-4"> </i>
    </a>

  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\cmsweb2\resources\views/layouts/partials/social.blade.php ENDPATH**/ ?>