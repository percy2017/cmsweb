<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(setting('site.title')); ?></title>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link href="<?php echo e(asset('vendor/mdb/lgp/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/mdb/lgp/css/mdb.min.css')); ?>" rel="stylesheet">

    <meta property="og:site_name" content="<?php echo e(setting('site.title')); ?>" />
    <meta property="og:title" content="<?php echo e(setting('site.title')); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo e(url('/plantillas')); ?>" />
    <meta property="og:image" content="<?php echo e(asset(setting('site.logo'))); ?>" />
    <meta property="og:description" content="<?php echo e(setting('site.description')); ?>" />
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/whatsapp/floating-wpp.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/share/css/contact-buttons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/up/css/floating-totop-button.css')); ?>">
   <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
</head>
<body>

    <div id="app">
        

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
     <div id="myWP"></div>
  <!-- SCRIPTS -->

  <!-- JQuery -->
  <script type="text/javascript" src="<?php echo e(asset('vendor/mdb/lgp/js/jquery-3.4.1.min.js')); ?>"></script>

  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo e(asset('vendor/mdb/lgp/js/popper.min.js')); ?>"></script>

  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo e(asset('vendor/mdb/lgp/js/bootstrap.min.js')); ?>"></script>

  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo e(asset('vendor/mdb/lgp/js/mdb.min.js')); ?>"></script>

  <script src="<?php echo e(asset('vendor/whatsapp/floating-wpp.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/up/js/floating-totop-button.js')); ?>"></script>
  <script>
    //Animation init
    new WOW().init();

    //Modal
    $('#myModal').on('shown.bs.modal', function () {
      $('#myInput').focus()
    })

    // Material Select Initialization
    $(document).ready(function () {
      $('.mdb-select').material_select();
    });


    $('#myWP').floatingWhatsApp({
      phone: '<?php echo e(setting('whatsapp.phone')); ?>',
      popupMessage: '<?php echo e(setting('whatsapp.popupMessage')); ?>',
      message: '<?php echo e(setting('whatsapp.message')); ?>',
      showPopup: true,
      showOnIE: true,
      headerTitle: '<?php echo e(setting('whatsapp.headerTitle')); ?>',
      headerColor: '<?php echo e(setting('whatsapp.color')); ?>',
      backgroundColor: '<?php echo e(setting('whatsapp.color')); ?>',
      buttonImage: '<img src="<?php echo e(Voyager::Image(setting('whatsapp.buttonImage' ))); ?>" />',
      position: '<?php echo e(setting('whatsapp.position')); ?>',
      autoOpenTimeout: <?php echo e(setting('whatsapp.autoOpenTimeout')); ?>,
      size: '<?php echo e(setting('whatsapp.size')); ?>'
    });

    // buttun up
    $("body").toTopButton({
      // path to icons
      imagePath: 'vendor/up/img/icons/',
      // arrow, arrow-circle, caret, caret-circle, circle, circle-o, arrow-l, drop, rise, top
      // or your own SVG icon
      arrowType: 'arrow',

      // 'w' = white
      // 'b' = black
      iconColor: 'w',
      
      // icon shadow
      // from 1 to 16
      iconShadow: 6

    });
  </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cmsweb2\resources\views/layouts/app.blade.php ENDPATH**/ ?>