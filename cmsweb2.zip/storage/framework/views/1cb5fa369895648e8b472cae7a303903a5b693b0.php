<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($hasChildren = count($menu_item->children) > 0); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e($menu_item->link()); ?>"><?php echo e($menu_item->title); ?></a>
        
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\cmsweb2\resources\views/layouts/partials/primary.blade.php ENDPATH**/ ?>