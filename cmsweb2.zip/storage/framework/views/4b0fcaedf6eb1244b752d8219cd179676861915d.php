<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-center">Mi Perfil</h4>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group row">
                        <img src="<?php echo e(Voyager::Image(Auth::user()->avatar)); ?>" alt="..." class="img-thumbnail col-md-6">
                        <address for="rol" class="col-md-6 col-form-label text-md-left">
                            <p><strong>Nombre: </strong><?php echo e(Auth::user()->name); ?></p>
                            <p><strong>Rol: </strong><?php echo e(Auth::user()->role->name); ?></p>
                            <p><strong>Usuario: </strong><?php echo e(Auth::user()->email); ?></p>
                            <p><strong>Registro: </strong><?php echo e(Auth::user()->created_at); ?></p>
                            <hr />
                            <?php if(Auth::user()->role->id == 1): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('voyager.dashboard')); ?>">Ir a Panel</a>
                            <?php endif; ?>
                            <a class="btn btn-default" href="/">Volver</a>
                        </address>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmsweb2\resources\views/home.blade.php ENDPATH**/ ?>