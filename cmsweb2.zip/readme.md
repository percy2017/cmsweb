
# Sobre CmsWeb v2020

En un software inteligente para crear y administrar paginas web dinamicas, utilizando las mejores practicas de la Internet 2.0

La herramienta inscluye paquete de terceros:

- [Laravel Framework v5.8](#)
- [Bootstrap Framework Css v3.7](#)
- [Voyager Pacakages v1.3](#)
- [VueJs Framework v2.5](#)
- [Fundation Framework Css v6.0](#)

# Installed
### Step #1

    Descarga el instalador del sitio oficial
- ***[Descargar el archivo comprimido (ZIP)   ](https://loginweb.net/cmsweb/download)***

### Step #2

    Realizar la instalación en un servidor web, mediante el asistente viernes v1.0

### Step #3

    Crear contenido para el sitio desde dashboard y disfrutar.

# CmsWeb Sponsors

La empresa detras del Diseño y Creacion del CmsWeb v2020 es:

- ***[LoginWeb - Empresa de Diseño y Desarrollo de Hardwre y Software](https://loginweb.net/)***

### Contributing

Los desarrolladores del CmsWeb son los Ingenieros Empiricos:
- [Luis Flores](#)


### License

CmsWeb v2020 is open-source software licensed under the [MIT license](https://opensource.org/licenses/MIT).
