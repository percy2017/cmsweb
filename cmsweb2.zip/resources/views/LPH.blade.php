<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>{{ setting('site.title') }}</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="vendor/mdb/lgp/css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="vendor/mdb/lgp/css/mdb.min.css" rel="stylesheet">
  <style type="text/css">
    html,
    body,
    header,
    .view.jarallax {
      height: 100%;
      min-height: 100%;
    }

  </style>

  
  <link rel="stylesheet" type="text/css" href="{{ asset('vendor/whatsapp/floating-wpp.css') }}">
  <link rel="stylesheet" href="{{ asset('vendor/share/css/contact-buttons.css') }}">
   @laravelPWA
</head>

<body class="hostel-lp">

  <!--Navigation & Intro-->
  <header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top scrolling-navbar">
      <div class="container">
        <a class="navbar-brand" href="#">{{ setting('site.title') }}</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
          aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav mr-auto smooth-scroll">
           {{ menu('primary', 'layouts.partials.primary') }}
          </ul>
          
        {{--  <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    Estilos <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="{{ route('template_change', 'LPS') }}">
                      LP - Software
                  </a>
                  <a class="dropdown-item" href="{{ route('template_change', 'LPR') }}">
                      LP - Restorant
                  </a>
                  <a class="dropdown-item active" href="{{ route('template_change', 'LPH') }}">
                      LP - Hotel
                  </a>
                  <hr />
                  <a class="dropdown-item" href="{{ route('template_change', 'EC1') }}">
                      EC - Ecommerce v1
                  </a>
                  <hr />
                  <a class="dropdown-item" href="/login">
                      Ves Mas
                  </a>
                </div>
            </li>
          </ul>  --}}
        </div>
         
          <ul class="navbar-nav nav-flex-icons">
           @guest
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('login') }}">
                      {{-- {{ __('Login') }} --}}
                      Ingresar
                    </a>
                </li>
                @if (Route::has('register'))
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('register') }}">
                          {{-- {{ __('Register') }} --}}
                          Registrarme
                        </a>
                    </li>
                @endif
            @else
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        {{ Auth::user()->name }} <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                      <a class="dropdown-item" href="/home">
                            Perfil
                        </a>

                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                          document.getElementById('logout-form').submit();">
                            Salir
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                </li>
            @endguest
          </ul>
         
        </div>
      </div>
    </nav>

    <!-- Intro Section -->
    <div id="home" class="view jarallax" data-jarallax='{"speed": 0.2}' max-height="700px"
      style="background-image: url('https://mdbootstrap.com/img/Photos/Horizontal/Nature/full page/img (29).jpg');">
      <div class="mask  rgba-black-slight">
        <div class="container h-100 d-flex justify-content-center align-items-center">
          <div class="row smooth-scroll">
            <div class="col-md-12 text-center white-text">
              <div class="wow fadeInDown" data-wow-delay="0.2s">
                <h1 class="white-text display-4 font-weight-bold mt-5 mt-xl-2">
                  <em>Welcome to our
                    <strong>Hotel</strong>
                  </em>
                </h1>

                <!--Rating-->
                <ul class="rating mt-3">
                  <li>
                    <i class="fas fa-star"></i>
                  </li>
                  <li>
                    <i class="fas fa-star"></i>
                  </li>
                  <li>
                    <i class="fas fa-star"></i>
                  </li>
                  <li>
                    <i class="fas fa-star"></i>
                  </li>
                  <li>
                    <i class="fas fa-star"></i>
                  </li>
                </ul>

                <h4 class="text-uppercase white-text mb-5 mt-3 font-weight-bold spacing">Feel like at home</h4>

                <a href="#rooms" class="btn btn-white dark-grey-text font-weight-bold btn-rounded spacing"
                  data-offset="100">
                  <strong>reservation</strong>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /Intro Section -->

  </header>
  <!--/Navigation & Intro-->

  <!--Main layout-->
  <main>

    <!--First container-->
    <div class="container">

      <!--Section: About-->
      <section id="about" class="mt-5">

        <!--Secion heading-->
        <h5 class="text-center dark-grey-text text-uppercase font-weight-bold spacing my-5 py-4 wow fadeIn"
          data-wow-delay="0.2s">
          <strong>Facts about us</strong>
        </h5>

        <!--Grid row-->
        <div class="row">

          <!--Grid column-->
          <div class="col-md-5">

            <img src="https://mdbootstrap.com/img/Photos/Others/hotel1.jpg" class="img-fluid z-depth-1 rounded"
              alt="sample image">

          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-md-6 ml-lg-5 justify-content-left">
            <hr class="line">

            <h3 class="text-left dark-grey-text text-center font-weight-bold pb-4 wow fadeIn" data-wow-delay="0.2s">
              <em>
                <strong>Lorem ipsum dolor sit amet</strong>
              </em>
            </h3>

            <p class="grey-text">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson
              ad squid. 3
              wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
              eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla
              assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt
              sapiente ea proident.
            </p>
            <p class="grey-text">Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
              proident.
              Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
              synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
            </p>
            <h5 class="text-right dark-grey-text font-weight-bold mt-5 wow fadeIn" data-wow-delay="0.2s">
              <em>
                <strong>John Doe</strong>
              </em>
            </h5>
            <p class="text-right grey-text wow fadeIn" data-wow-delay="0.2s">
              <em>Director of the hotel</em>
            </p>

          </div>
          <!--Grid column-->

        </div>
        <!--Grid row-->

      </section>
      <!--/Section: About-->

      <hr class="wow fadeIn mt-5" data-wow-delay="0.4s">

      <!--Section: Rooms-->
      <section id="room">

        <!--Secion heading-->
        <h5 class="text-center dark-grey-text text-uppercase font-weight-bold spacing my-5 py-4 wow fadeIn"
          data-wow-delay="0.2s">
          <strong>HOTEL MASTER'S ROOMS</strong>
        </h5>

        <!--Carousel Wrapper-->
        <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">

          <!--Controls-->
          <div class="controls-top">
            <a class="mr-3" href="#multi-item-example" data-slide="prev">
              <i class="fas fa-chevron-left info-text"></i>
            </a>
            <a class="ml-3" href="#multi-item-example" data-slide="next">
              <i class="fas fa-chevron-right info-text"></i>
            </a>
          </div>
          <!--/.Controls-->

          <!--Slides-->
          <div class="carousel-inner" role="listbox">

            <!--First slide-->
            <div class="carousel-item active">

              <div class="col-md-4">

                <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/25.jpg"
                  alt="Card image cap">

                <p class="text-uppercase font-weight-bold dark-grey-text spacing mt-3 mb-0">DELUXE ROOM with terrace</p>
                <a>
                  <p class="info-text mt-1">
                    <em>Check details</em>
                  </p>
                </a>

              </div>

              <div class="col-md-4 clearfix d-none d-md-block">
                <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/27.jpg"
                  alt="Card image cap">

                <p class="text-uppercase font-weight-bold dark-grey-text spacing mt-3 mb-0">room with swimming pool</p>
                <a>
                  <p class="info-text mt-1">
                    <em>Check details</em>
                  </p>
                </a>

              </div>

              <div class="col-md-4 clearfix d-none d-md-block">
                <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/23.jpg"
                  alt="Card image cap">

                <p class="text-uppercase font-weight-bold dark-grey-text spacing mt-3 mb-0">room with ocean view</p>
                <a>
                  <p class="info-text mt-1">
                    <em>Check details</em>
                  </p>
                </a>

              </div>

            </div>
            <!--/.First slide-->

            <!--Second slide-->
            <div class="carousel-item">

              <div class="col-md-4">
                <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/26.jpg"
                  alt="Card image cap">

                <p class="text-uppercase font-weight-bold dark-grey-text spacing mt-3 mb-0">ROOM with ocean view</p>
                <a>
                  <p class="info-text mt-1">
                    <em>Check details</em>
                  </p>
                </a>

              </div>

              <div class="col-md-4 clearfix d-none d-md-block">
                <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/21.jpg"
                  alt="Card image cap">

                <p class="text-uppercase font-weight-bold dark-grey-text spacing mt-3 mb-0">DELUXE ROOM – ONE KING BED
                </p>
                <a>
                  <p class="info-text mt-1">
                    <em>Check details</em>
                  </p>
                </a>

              </div>

              <div class="col-md-4 clearfix d-none d-md-block">
                <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/24.jpg"
                  alt="Card image cap">

                <p class="text-uppercase font-weight-bold dark-grey-text spacing mt-3 mb-0">Room with exclusive pool</p>
                <a>
                  <p class="info-text mt-1">
                    <em>Check details</em>
                  </p>
                </a>

              </div>

            </div>
            <!--/.Second slide-->

          </div>
          <!--/.Slides-->

        </div>
        <!--/.Carousel Wrapper-->

      </section>
      <!--/Section: Rooms-->

    </div>
    <!--/First container-->

    <!--Second container-->
    <div class="container-fluid light-grey-background">
      <div class="container py-4">

        <!--Section: Facilities-->
        <section id="facilities" class="mt-3 mb-3 pb-3">

          <h5 class="text-center dark-grey-text text-uppercase font-weight-bold spacing my-5 pt-2 pb-4 wow fadeIn"
            data-wow-delay="0.2s">
            <strong>Facilities</strong>
          </h5>

          <!-- First row -->
          <div class="row  wow fadeIn" data-wow-delay="0.4s">

            <!-- First column -->
            <div class="col-md-4 mb-4 text-center">

              <!--Panel-->
              <div class="card card-body rgba-white-light hoverable">
                <i class="fas fa-utensils fa-2x mb-4 mt-3 dark-grey-text" aria-hidden="true"></i>
                <p class="font-weight-bold font-weight-bold dark-grey-text text-uppercase spacing">
                  <strong>restaurant</strong>
                </p>
                <p class="dark-grey-text font-small">Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred
                  nesciunt sapiente earu
                  proident. Ad vegan excepteur butcher vice lomo leggings occaecat.
                </p>
              </div>
              <!--/.Panel-->

            </div>
            <!-- /First column -->

            <!-- Second column -->
            <div class="col-md-4 mb-4 text-center">

              <!--Panel-->
              <div class="card card-body rgba-white-light hoverable">
                <i class="fas fa-wifi  fa-2x mb-4 mt-3 dark-grey-text" aria-hidden="true"></i>
                <p class="font-weight-bold font-weight-bold dark-grey-text text-uppercase spacing">
                  <strong>free wi-fi</strong>
                </p>
                <p class="dark-grey-text font-small">Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred
                  nesciunt sapiente earu
                  proident. Ad vegan excepteur butcher vice lomo leggings occaecat.
                </p>
              </div>
              <!--/.Panel-->

            </div>
            <!-- /.Second column -->

            <!-- Third column -->
            <div class="col-md-4 mb-4 text-center">

              <!--Panel-->
              <div class="card card-body rgba-white-light hoverable">
                <i class="fas fa-tint fa-2x mb-4 mt-3 dark-grey-text" aria-hidden="true"></i>
                <p class="font-weight-bold font-weight-bold dark-grey-text text-uppercase spacing">
                  <strong>spa & pool</strong>
                </p>
                <p class="dark-grey-text font-small">Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred
                  nesciunt sapiente earu
                  proident. Ad vegan excepteur butcher vice lomo leggings occaecat.
                </p>
              </div>
              <!--/.Panel-->

            </div>
            <!-- /.Third column -->

          </div>
          <!-- /.First row -->

        </section>
        <!--/Section: Facilities-->

      </div>
    </div>
    <!--Second container-->

    <div class="streak streak-md streak-photo"
      style="background-image:url('https://mdbootstrap.com/img/Photos/Horizontal/Nature/full page/img(27).jpg')">
      <div class="flex-center white-text rgba-white-slight">
        <ul class="list-unstyled mb-0">
          <li>
            <h1 class="h1-responsive font-weight-bold mb-4 spacing">
              <em>Unforgettable
                <strong>holidays</strong>
              </em>
            </h1>
          </li>
          <li class="mb-5">
            <h6 class="text-center font-italic mb-0">Cruises | Scuba diving | Local travels</h6>
          </li>
          <button class="btn btn-white dark-grey-text font-weight-bold spacing btn-rounded">
            <strong>Book a room</strong>
          </button>
        </ul>
      </div>
    </div>

    <!--Third container-->
    <div class="container">

      <!--Section: Offers-->
      <section id="offers" class="pt-2 mt-3 pb-3">

        <h5 class="text-center dark-grey-text text-uppercase font-weight-bold spacing my-5 pt-2 pb-4 wow fadeIn"
          data-wow-delay="0.2s">
          <strong>top offers</strong>
        </h5>

        <!-- Grid row -->
        <div class="row">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-4">

            <!--Card-->
            <div class="card card-personal mb-4">

              <!--Card image-->
              <div class="view overlay">
                <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Others/images/26.jpg"
                  alt="Card image cap">
                <a href="#!">
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <!--Card image-->

              <!--Card content-->
              <div class="card-body">
                <!--Title-->
                <a>
                  <h5 class="font-weight-bold text-uppercase">
                    <strong>ROOM WITH OCEAN VIEW</strong>
                  </h5>
                </a>
                <a>
                  <span class="badge badge-info py-2 px-2">$ 250</span>
                </a>

                <!--Text-->
                <p class="grey-text mt-2">Some quick example text to build on the card title and make up the bulk of the
                  card's content.
                  <!--Grid row-->
                  <div class="row">

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-12 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-hotel dark-grey-text" aria-hidden="true"></i> 3 beds</p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-12 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-utensils dark-grey-text" aria-hidden="true"></i> Launches</p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-12 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-wifi dark-grey-text" aria-hidden="true"></i> Wi-Fi</p>
                    </div>
                    <!--Grid column-->

                  </div>
                  <!--Grid row-->
                </p>
                <hr>
                <!--Grid column-->
                <div class="col-12 text-center">
                  <button class="btn btn-info btn-sm font-weight-bold btn-rounded">
                    <strong>Book a room</strong>
                  </button>
                </div>
                <!--Grid column-->

              </div>
              <!--Card content-->

            </div>
            <!--Card-->

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-4">

            <!--Card-->
            <div class="card card-personal mb-4">

              <!--Card image-->
              <div class="view overlay">
                <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Others/images/21.jpg"
                  alt="Card image cap">
                <a href="#!">
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <!--Card image-->

              <!--Card content-->
              <div class="card-body">
                <!--Title-->
                <a>
                  <h5 class="font-weight-bold text-uppercase">
                    <strong>EXCLUSIVE APARTMENT</strong>
                  </h5>
                </a>
                <a>
                  <span class="badge badge-info py-2 px-2">$ 150</span>
                </a>

                <!--Text-->
                <p class="grey-text mt-2">Some quick example text to build on the card title and make up the bulk of the
                  card's content.
                  <!--Grid row-->
                  <div class="row">

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-12 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-hotel dark-grey-text" aria-hidden="true"></i> 1 bed</p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-12 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-utensils dark-grey-text" aria-hidden="true"></i> Launches</p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-12 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-wifi dark-grey-text" aria-hidden="true"></i> Wi-Fi</p>
                    </div>
                    <!--Grid column-->

                  </div>
                  <!--Grid row-->
                </p>
                <hr>
                <!--Grid column-->
                <div class="col-12 text-center">
                  <button class="btn btn-info btn-sm font-weight-bold btn-rounded">
                    <strong>Book a room</strong>
                  </button>
                </div>
                <!--Grid column-->

              </div>
              <!--Card content-->

            </div>
            <!--Card-->

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-12 col-lg-4">

            <!--Card-->
            <div class="card card-personal mb-4">

              <!--Card image-->
              <div class="view overlay">
                <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Others/images/25.jpg"
                  alt="Card image cap">
                <a href="#!">
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <!--Card image-->

              <!--Card content-->
              <div class="card-body">
                <!--Title-->
                <a>
                  <h5 class="font-weight-bold text-uppercase">
                    <strong>ROOM WITH TERRACE</strong>
                  </h5>
                </a>
                <a>
                  <span class="badge badge-info py-2 px-2">$ 350</span>
                </a>

                <!--Text-->
                <p class="grey-text mt-2">Some quick example text to build on the card title and make up the bulk of the
                  card's content.
                  <!--Grid row-->
                  <div class="row">

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-4 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-hotel dark-grey-text" aria-hidden="true"></i> 3 beds</p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-4 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-utensils dark-grey-text" aria-hidden="true"></i> Launches</p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-4 text-center">
                      <p class="dark-grey-text">
                        <i class="fas fa-wifi dark-grey-text" aria-hidden="true"></i> Wi-Fi</p>
                    </div>
                    <!--Grid column-->

                  </div>
                  <!--Grid row-->
                </p>
                <hr>
                <!--Grid column-->
                <div class="col-12 text-center">
                  <button class="btn btn-info btn-sm font-weight-bold btn-rounded">
                    <strong>Book a room</strong>
                  </button>
                </div>
                <!--Grid column-->

              </div>
              <!--Card content-->

            </div>
            <!--Card-->

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </section>
      <!--Section: Offers-->

      <hr class="wow fadeIn mt-5" data-wow-delay="0.4s">

      <!--Section: Attractions-->
      <section class="mb-5 pt-3 pb-3 wow fadeIn" data-wow-delay="0.2s">
        <h5 class="text-center dark-grey-text text-uppercase font-weight-bold spacing my-5 pt-2 pb-4 wow fadeIn"
          data-wow-delay="0.2s">
          <strong>Attractions</strong>
        </h5>

        <!--Grid row-->
        <div class="row">

          <!--Grid column-->
          <div class="col-lg-5 col-md-12 mb-4">

            <img class="img-fluid z-depth-1 rounded" src="https://mdbootstrap.com/img/Photos/Others/images/29.jpg"
              alt="Card image cap">

          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-7 col-md-12">

            <p class="grey-text">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson
              ad squid. 3
              wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum
              eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla
              assumenda shoreditch.
            </p>


            <!--Grid row-->
            <div class="row mt-4">

              <!--Grid column-->
              <div class="col-md-6 col-6 mb-4">
                <div class="col-1 col-md-2 float-left">
                  <i class="fas fa-camera-retro fa-2x info-text"></i>
                </div>
                <div class="col-10 col-md-9 col-lg-10 float-right">
                  <h6 class="font-weight-bold info-text mt-2">Local travels</h6>
                  <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores
                    nam,
                    aperiam minima assumenda.</p>

                </div>
              </div>
              <!--Grid column-->

              <!--Grid column-->
              <div class="col-md-6 col-6 mb-4">
                <div class="col-1 col-md-2 float-left">
                  <i class="fas fa-tint fa-2x info-text"></i>
                </div>
                <div class="col-10 col-md-9 col-lg-10 float-right">
                  <h6 class="font-weight-bold info-text mt-2">Spa & pools</h6>
                  <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores
                    nam,
                    aperiam minima assumenda.</p>

                </div>
              </div>
              <!--Grid column-->


            </div>
            <!--Grid row-->

          </div>
          <!--Grid column-->

        </div>
        <!--Grid row-->

      </section>
      <!--/Section: Attractions-->

      <hr class="wow fadeIn mt-5" data-wow-delay="0.4s">

      <!--Section: Reservation-->
      <section id="reservation" class="mb-5 pt-3 pb-5 wow fadeIn" data-wow-delay="0.2s">

        <h5 class="text-center dark-grey-text text-uppercase font-weight-bold spacing my-5 py-4 wow fadeIn"
          data-wow-delay="0.2s">
          <strong>Reservation</strong>
        </h5>

        <!--Grid row-->
        <div class="row">

          <!--Grid column-->
          <div class="col-lg-4 col-md-12">

            <div class="input-group md-form form-sm form-3 pl-0">
              <div class="input-group-prepend w-100">
                <span class="input-group-text white black-text" id="basic-addon8">1</span>
                <input type="text" class="form-control mt-0 blue-border rgba-white-strong" placeholder="Name"
                  aria-describedby="basic-addon8">
              </div>
            </div>

          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-4 col-md-6">

            <div class="input-group md-form form-sm form-3 pl-0">
              <div class="input-group-prepend w-100">
                <span class="input-group-text white black-text" id="basic-addon9">2</span>
                <input type="text" class="form-control mt-0 blue-border rgba-white-strong" placeholder="Email"
                  aria-describedby="basic-addon9">
              </div>
            </div>

          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-4 col-md-6">

            <div class="input-group md-form form-sm form-3 pl-0">
              <div class="input-group-prepend w-100">
                <span class="input-group-text white black-text" id="basic-addon10">3</span>
                <input type="text" class="form-control mt-0 blue-border rgba-white-strong" placeholder="Website"
                  aria-describedby="basic-addon10">
              </div>
            </div>

          </div>
          <!--Grid column-->

        </div>
        <!--Grid row-->

        <!--Grid row-->
        <div class="row mt-4">

          <!--Grid column-->
          <div class="col-lg-12 col-md-12">

            <div class="form-group basic-textarea">
              <label for="exampleFormControlTextarea2" class="font-small grey-text">Your message</label>
              <textarea class="form-control" id="exampleFormControlTextarea2" rows="3"></textarea>
            </div>
            <button class="btn btn-info btn-sm font-weight-bold btn-rounded waves-effect waves-light ml-0">
              <strong>Book a room</strong>
            </button>

          </div>
          <!--Grid column-->

        </div>
        <!--Grid row-->

      </section>
      <!--/Section: Reservation-->

    </div>
    <!--/Third container-->

  </main>
  <!--/Main layout-->

  <!--Footer-->
  <footer class="page-footer text-center text-md-left blue-grey lighten-5 pt-0">

    <div class="top-footer-color">
      <div class="container">
        <!--Grid row-->
        <div class="row py-4 d-flex align-items-center justify-content-center">

          <!--Grid column-->
          <div class="col-12 col-md-5 text-left  mb-md-0">
            <h6 class="mb-0 white-text text-center text-md-left">
              <strong>Get connected with us on social networks!</strong>
            </h6>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-12 col-md-7 text-center text-md-right">
            <!--Facebook-->
            <a class="p-2 m-2 fa-lg fb-ic ml-0">
              <i class="fab fa-facebook-f white-text mr-lg-4"> </i>
            </a>
            <!--Twitter-->
            <a class="p-2 m-2 fa-lg tw-ic">
              <i class="fab fa-twitter white-text mr-lg-4"> </i>
            </a>
            <!--Google +-->
            <a class="p-2 m-2 fa-lg gplus-ic">
              <i class="fab fa-google-plus-g white-text mr-lg-4"> </i>
            </a>
            <!--Linkedin-->
            <a class="p-2 m-2 fa-lg li-ic">
              <i class="fab fa-linkedin-in white-text mr-lg-4"> </i>
            </a>
            <!--Instagram-->
            <a class="p-2 m-2 fa-lg ins-ic">
              <i class="fab fa-instagram white-text mr-lg-4"> </i>
            </a>
          </div>
          <!--Grid column-->

        </div>
        <!--Grid row-->
      </div>
    </div>

    <!--Footer Links-->
    <div class="container mt-5 mb-4 text-center text-md-left">
      <div class="row mt-3">

        <!--First column-->
        <div class="col-md-3 col-lg-4 col-xl-3 mb-4 dark-grey-text">
          <h6 class="text-uppercase font-weight-bold">
            <strong>Company name</strong>
          </h6>
          <hr class="cyan mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet,
            consectetur
            adipisicing elit.</p>
        </div>
        <!--/.First column-->

        <!--Second column-->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4 dark-grey-text">
          <h6 class="text-uppercase font-weight-bold">
            <strong>Attractions</strong>
          </h6>
          <hr class="cyan mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="#!" class="dark-grey-text">Spa</a>
          </p>
          <p>
            <a href="#!" class="dark-grey-text">Restaurant</a>
          </p>
          <p>
            <a href="#!" class="dark-grey-text">Gym & pool</a>
          </p>
          <p>
            <a href="#!" class="dark-grey-text">Local travels</a>
          </p>
        </div>
        <!--/.Second column-->

        <!--Third column-->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4 dark-grey-text">
          <h6 class="text-uppercase font-weight-bold">
            <strong>Useful links</strong>
          </h6>
          <hr class="cyan mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="#!" class="dark-grey-text">Reservation</a>
          </p>
          <p>
            <a href="#!" class="dark-grey-text">Tourist attraction</a>
          </p>
          <p>
            <a href="#!" class="dark-grey-text">Hotel's menu</a>
          </p>
          <p>
            <a href="#!" class="dark-grey-text">Help</a>
          </p>
        </div>
        <!--/.Third column-->

        <!--Fourth column-->
        <div class="col-md-4 col-lg-3 col-xl-3 dark-grey-text">
          <h6 class="text-uppercase font-weight-bold">
            <strong>Contact</strong>
          </h6>
          <hr class="cyan mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <i class="fas fa-home mr-3"></i> New York, NY 10012, US</p>
          <p>
            <i class="fas fa-envelope mr-3"></i> info@example.com</p>
          <p>
            <i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
          <p>
            <i class="fas fa-print mr-3"></i> + 01 234 567 89</p>
        </div>
        <!--/.Fourth column-->

      </div>
    </div>
    <!--/.Footer Links-->

    <!-- Copyright-->
    <div class="footer-copyright py-3 text-center">
      <div class="container-fluid">
        © 2019 Copyright: <a href="https://mdbootstrap.com/education/bootstrap/" target="_blank"> MDBootstrap.com </a>
      </div>
    </div>
    <!--/.Copyright -->

  </footer>
  <!--/.Footer-->

  <!-- SCRIPTS -->

<div id="myWP"></div>

  <!-- JQuery -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/mdb.min.js"></script>
  <!--Google maps-->
  <script src="http://maps.google.com/maps/api/js"></script>

  <script src="vendor/whatsapp/floating-wpp.js"></script>
   <script src="{{ asset('vendor/share/js/jquery.contact-buttons.js') }}"></script>
  <!-- Custom scripts -->
  <script>
    // Animation init
    new WOW().init();

        $('#myWP').floatingWhatsApp({
      phone: '{{ setting('whatsapp.phone') }}',
      popupMessage: '{{ setting('whatsapp.popupMessage') }}',
      message: '{{ setting('whatsapp.message') }}',
      showPopup: true,
      showOnIE: true,
      headerTitle: '{{ setting('whatsapp.headerTitle') }}',
      headerColor: '{{ setting('whatsapp.color') }}',
      backgroundColor: '{{ setting('whatsapp.color') }}',
      buttonImage: '<img src="{{ asset('storage/'.setting('whatsapp.buttonImage') ) }}" />',
      position: '{{ setting('whatsapp.position') }}',
      autoOpenTimeout: {{ setting('whatsapp.autoOpenTimeout') }},
      size: '{{ setting('whatsapp.size') }}'
    });
        // Initialize Share-Buttons
    $.contactButtons({
      effect  : 'slide-on-scroll',
      buttons : {
        'facebook':   { class: 'facebook', use: true, link: 'https://www.facebook.com/sharer/sharer.php?u='+window.location, extras: 'target="_blank"' },
        'twitter':   { class: 'twitter', use: true, link: 'https://twitter.com/home?status='+window.location, extras: 'target="_blank"' },
        'whatsapp':   { class: 'whatsapp', use: true, link: 'https://api.whatsapp.com/send?text='+window.location, extras: 'target="_blank"' }
      }
    });
  </script>

</body>

</html>
