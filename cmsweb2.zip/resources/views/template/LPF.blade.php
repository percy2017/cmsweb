<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    @include('template.partials.meta')
    <style>
        html,
        body,
        header,
        .view.jarallax {
        height: 100%;
        min-height: 100%;
        }
    </style>
</head>

<body class="cafe-lp">

    <!-- Main Navigation -->
    <header>

        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top scrolling-navbar brown darken-3">
        <div class="container">
            <a class="navbar-brand" href="#">{{ setting('site.title') }}</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto smooth-scroll">
                {{ menu('primary', 'layouts.partials.primary') }}
            </ul>
            <!-- Social Icons -->
            <ul class="navbar-nav nav-flex-icons">
                @guest
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('login') }}">
                      Ingresar
                    </a>
                </li>
                @if (Route::has('register'))
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('register') }}">
                          Registrarme
                        </a>
                    </li>
                @endif
            @else
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        {{ Auth::user()->name }} <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                      <a class="dropdown-item" href="/home">
                            Perfil
                        </a>

                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                          document.getElementById('logout-form').submit();">
                            Salir
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                </li>
            @endguest
            </ul>
            </div>
        </div>
        </nav>

        <!-- Intro Section -->
        <div id="home" class="view jarallax" data-jarallax='{"speed": 0.2}'>
        <div class="mask rgba-black-strong">
            <div class="container h-100 d-flex justify-content-center align-items-center">
            <div class="row smooth-scroll">
                <div class="col-md-12 text-center white-text">
                <div class="wow fadeInDown" data-wow-delay="0.2s">
                    <hr class="white">
                    <h1 class="white-text display-4 font-weight-bold">
                    <em>Welcome to our Organic cafe
                    </em>
                    </h1>
                    <hr class="white">
                    <h5 class="text-uppercase white-text my-5 font-weight-bold spacing">Lorem ipsum dolor sit amet</h5>
                    <a href="#features" class="btn rgba-white-strong btn-rounded dark-grey-text font-weight-bold" data-offset="80">Welcome</a>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>

    </header>
    <!-- Main Navigation -->

    <!-- Main content -->
    <main>

        <div class="container">

        <!-- Section: Features v.4 -->
        <section class="mt-5" id="features">

            <!-- Secion heading -->
            <h1 class="text-center font-weight-bold mt-5 pt-5 mb-3 drk-grey-text wow fadeIn" data-wow-delay="0.2s">
            <em>Welcome to our cafe</em>
            </h1>

            <!-- Section description -->
            <p class="text-center text-uppercase grey-text font-weight-bold mb-5 pb-4 wow fadeIn" data-wow-delay="0.2s">We
            serve the best coffee</p>

            <!-- Grid row -->
            <div class="row wow fadeIn" data-wow-delay="0.4s">

            <!-- Grid column -->
            <div class="col-md-4">

                <!-- Grid row -->
                <div class="row text-center pb-5">
                <div class="col-md-12">
                    <i class="fas fa-home fa-3x brown-text pb-3"></i>
                    <h4 class="font-weight-bold">100% Natural</h4>
                    <p class="grey-text">Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.</p>
                </div>
                </div>
                <!-- Grid row -->

                <!-- Grid row -->
                <div class="row text-center pb-5">
                <div class="col-md-12">
                    <i class="fas fa-umbrella fa-3x brown-text pb-3"></i>
                    <h4 class="font-weight-bold">Always fresh</h4>
                    <p class="grey-text">Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.</p>
                </div>
                </div>
                <!-- Grid row -->

            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 pb-3 flex-center">
                <img src="https://mdbootstrap.com/img/Photos/Others/coffee.jpg" alt="" class="z-depth-0 img-fluid">
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4">

                <!-- Grid row -->
                <div class="row text-center pb-5">
                <div class="col-md-12">
                    <i class="fas fa-users fa-3x brown-text pb-3"></i>
                    <h4 class="font-weight-bold">Organic products</h4>
                    <p class="grey-text">Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.</p>
                </div>
                </div>
                <!-- Grid row -->

                <!-- Grid row -->
                <div class="row text-center pb-5">
                <div class="col-md-12">
                    <i class="fas fa-tachometer-alt fa-3x brown-text pb-3"></i>
                    <h4 class="font-weight-bold">Best Quality</h4>
                    <p class="grey-text">Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.</p>
                </div>
                </div>
                <!-- Grid row -->

            </div>
            <!-- Grid column -->

            </div>
            <!-- Grid row -->

        </section>
        <!-- Section: Features v.4 -->

        <hr class="wow fadeIn" data-wow-delay="0.4s">

        <!-- Section: About -->
        <section class="about mb-5 pb-5" id="about">

            <!-- Secion heading -->
            <h1 class="text-center font-weight-bold pt-5 mb-3 drk-grey-text wow fadeIn" data-wow-delay="0.2s">
            <em>About us</em>
            </h1>

            <!-- Section description -->
            <p class="text-center text-uppercase font-weight-bold grey-text mb-5 pb-4 wow fadeIn" data-wow-delay="0.2s">With
            love to nature</p>

            <!-- Grid row -->
            <div class="row">

            <!-- Column column -->
            <div class="col-xl-5 mr-auto col-lg-6 wow fadeIn mb-lg-0 mb-4" data-wow-delay="0.4s">

                <!-- Image -->
                <img src="https://mdbootstrap.com/img/Photos/Horizontal/Food/6-col/img%20%2865%29.jpg" class="img-fluid rounded z-depth-1-half"
                alt="My photo">

            </div>
            <!-- Column column -->

            <!-- Grid column column -->
            <div class="col-xl-6 col-lg-6 pb-3 wow fadeIn" data-wow-delay="0.4s">

                <!-- Description -->
                <p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo animi soluta ratione
                quisquam, dicta
                ab cupiditate iure eaque? Repellendus voluptatum, magni impedit eaque animi maxime.</p>

                <p align="justify">Nemo animi soluta ratione quisquam, dicta ab cupiditate iure eaque? Repellendus
                voluptatum, magni
                impedit eaque delectus, beatae maxime temporibus maiores quibusdam quasi rem magnam.</p>

                <ul>
                <li>Nemo animi soluta ratione</li>
                <li>Beatae maxime temporibus</li>
                <li>Consectetur adipisicing elit</li>
                </ul>

            </div>
            <!-- Grid column -->

            </div>
            <!-- Grid row -->

        </section>
        <!-- Section: About -->

        </div>

        <!-- Streak -->
        <div class="streak streak-photo streak-md" style="background-image: url('https://mdbootstrap.com/img/Photos/Others/images/36.jpg');">
        <div class="mask rgba-black-strong flex-center">
            <div class="text-center text-white wow fadeIn" data-wow-delay="0.4s">
            <h2 class="font-weight-bold mb-3 pt-4 mt-4">We are opening a new cafe in New York!</h2>
            <p class="font-weight-bold grey-text">Friday 17/10/2018, 8:00 am</p>

            <!--Grid row-->
            <div class="row mt-5 mb-5">

                <!--Grid column-->
                <div class="col-lg-4 col-md-4">
                <hr class="white mx-5">
                <h1 class="display-4 font-weight-bold white-text">
                    <strong>20</strong>
                </h1>
                <hr class="white mx-5">
                <p class="font-weight-bold spacing">DAYS</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-4 col-md-4">
                <h1 class="display-4 font-weight-bold white-text rgba-white-light mx-4 py-3 mt-3">
                    <strong>12</strong>
                </h1>
                <p class="font-weight-bold spacing pt-3">HOURS</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-4 col-md-4">
                <hr class="white mx-5">
                <h1 class="display-4 font-weight-bold white-text">
                    <strong>35</strong>
                </h1>
                <hr class="white mx-5">
                <p class="font-weight-bold spacing">MINS</p>
                </div>
                <!--Grid column-->

            </div>
            <!--Grid row-->
            </div>
        </div>
        </div>
        <!-- Streak -->

        <div class="container">

        <!-- Section: Products -->
        <section id="products">

            <!-- Secion heading -->
            <h1 class="text-center font-weight-bold mt-4 pt-5 mb-3 wow fadeIn" data-wow-delay="0.2s">
            <em>Our products</em>
            </h1>

            <!-- Section description -->
            <p class="text-center text-uppercase grey-text font-weight-bold mb-5 pb-4 wow fadeIn" data-wow-delay="0.2s">The
            best coffee and food</p>

            <!--Grid row-->
            <div class="row">

            <!--Grid column-->
            <div class="col-md-12 col-lg-5 mb-5">

                <!-- Title 1-->
                <h5 class="font-weight-bold dark-grey-text">Regular Coffee</h5>

                <!--Grid row-->
                <div class="row pb-2">

                <!--Grid column-->
                <div class="col-md-6">
                    <p class="mb-0 grey-text">Lorem ipsum dolor sit</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 text-right">
                    <p class="mb-0 dark-grey-text font-weight-bold">$13</p>
                </div>
                <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr>

                <!-- Title 2 -->
                <h5 class="font-weight-bold dark-grey-text pt-2">Americano</h5>

                <!--Grid row-->
                <div class="row pb-2">

                <!--Grid column-->
                <div class="col-md-6">
                    <p class="mb-0 grey-text">Lorem ipsum dolor sit</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 text-right">
                    <p class="mb-0 dark-grey-text font-weight-bold">$15</p>
                </div>
                <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr>
                <!-- Title 3 -->
                <h5 class="font-weight-bold dark-grey-text pt-2">Cappuccino</h5>

                <!--Grid row-->
                <div class="row pb-2">

                <!--Grid column-->
                <div class="col-md-6">
                    <p class="mb-0 grey-text">Lorem ipsum dolor sit</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 text-right">
                    <p class="mb-0 dark-grey-text font-weight-bold">$18</p>
                </div>
                <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr>

                <!-- Title 4 -->
                <h5 class="font-weight-bold dark-grey-text pt-2">Vanila Latte</h5>

                <!--Grid row-->
                <div class="row pb-2">

                <!--Grid column-->
                <div class="col-md-6">
                    <p class="mb-0 grey-text">Lorem ipsum dolor sit</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 text-right">
                    <p class="mb-0 dark-grey-text font-weight-bold">$21</p>
                </div>
                <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr>

                <!-- Title 5 -->
                <h5 class="font-weight-bold dark-grey-text pt-2">Caramel Latte</h5>

                <!--Grid row-->
                <div class="row pb-2">

                <!--Grid column-->
                <div class="col-md-6">
                    <p class="mb-0 grey-text">Lorem ipsum dolor sit</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 text-right">
                    <p class="mb-0 dark-grey-text font-weight-bold">$17</p>
                </div>
                <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr>

                <!-- Title 6 -->
                <h5 class="font-weight-bold dark-grey-text pt-2">Mocha</h5>

                <!--Grid row-->
                <div class="row pb-2">

                <!--Grid column-->
                <div class="col-md-6">
                    <p class="mb-0 grey-text">Lorem ipsum dolor sit</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 text-right">
                    <p class="mb-0 dark-grey-text font-weight-bold">$25</p>
                </div>
                <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr>

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-12 col-lg-7">


                <!--Grid row-->
                <div class="row">

                <div class="col-md-6 mb-4">
                    <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/34.jpg" alt="Card image cap">
                </div>
                <div class="col-md-6 mb-4">
                    <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Others/images/35.jpg" alt="Card image cap">
                </div>
                <div class="col-md-6 mb-4">
                    <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Vertical/1.jpg" alt="Card image cap">
                </div>
                <div class="col-md-6 mb-4">
                    <img class="img-fluid rounded" src="https://mdbootstrap.com/img/Photos/Vertical/2.jpg" alt="Card image cap">
                </div>

                </div>
                <!--Grid row-->


            </div>
            <!--Grid column-->

            </div>
            <!--Grid row-->

        </section>
        <!-- Section: Products -->

        <hr class="wow fadeIn" data-wow-delay="0.4s">

        <!-- Section: Testimonials v.3 -->
        <section class="team-section pb-5" id="testimonials">

            <!-- Secion heading -->
            <h1 class="text-center font-weight-bold mt-5 pt-4 mb-3 wow fadeIn" data-wow-delay="0.2s">
            <em>Testimonials</em>
            </h1>

            <!-- Section description -->
            <p class="text-center text-uppercase font-weight-bold grey-text mb-5 pb-4 wow fadeIn" data-wow-delay="0.2s">What
            happy customers say</p>

            <!-- Grid row -->
            <div class="row text-center">

            <!-- Grid column -->
            <div class="col-md-4 mb-4 wow fadeIn" data-wow-delay="0.4s">

                <div class="testimonial">
                <!-- Avatar -->
                <div class="avatar mx-auto mb-4">
                    <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(20).jpg" class="rounded-circle img-fluid z-depth-1-half">
                </div>

                <!-- Content -->
                <h5 class="dark-grey-text font-weight-bold">
                    <strong>Anna Deynah</strong>
                </h5>
                <p>
                    <i class="fas fa-quote-left grey-text"></i> Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Quod eos id officiis hic tenetur
                    quae quaerat ad velit.</p>

                <!-- Review -->
                <div class="grey-text">
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star-half-alt"> </i>
                </div>
                </div>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 mb-4 wow fadeIn" data-wow-delay="0.4s">
                <div class="testimonial">
                <!-- Avatar -->
                <div class="avatar mx-auto mb-4">
                    <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(9).jpg" class="rounded-circle img-fluid z-depth-1-half">
                </div>

                <!-- Content -->
                <h5 class="dark-grey-text font-weight-bold">
                    <strong>John Doe</strong>
                </h5>
                <p>
                    <i class="fas fa-quote-left grey-text"></i> Ut enim ad minima veniam, quis nostrum exercitationem ullam
                    corporis suscipit laboriosam,
                    nisi ut aliquid ex.</p>

                <!-- Review -->
                <div class="grey-text">
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                </div>
                </div>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 mb-4 wow fadeIn" data-wow-delay="0.4s">
                <div class="testimonial">
                <!-- Avatar -->
                <div class="avatar mx-auto mb-4">
                    <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(19).jpg" class="rounded-circle img-fluid z-depth-1-half">
                </div>
                <!-- Content -->
                <h5 class="dark-grey-text font-weight-bold">
                    <strong>Maria Kate</strong>
                </h5>
                <p>
                    <i class="fas fa-quote-left grey-text"></i> At vero eos et accusamus et iusto odio dignissimos ducimus
                    qui blanditiis praesentium
                    voluptatum deleniti atque.</p>

                <!-- Review -->
                <div class="grey-text">
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="fas fa-star"> </i>
                    <i class="far fa-star"> </i>
                </div>

                </div>
            </div>
            <!-- Grid column -->

            </div>
            <!-- Grid row -->

        </section>
        <!-- Section: Testimonials v.3 -->

        </div>

    </main>
    <!-- Main content -->

    <!-- Footer -->
    <footer class="page-footer footer-tiles text-center text-md-left brown darken-3 pt-4">

        <!-- Footer Links -->
        <div class="container mb-5 mt-5">

        <!-- Grid row -->
        <div class="row">

            <!-- Grid column -->
            <div class="col-xl-4 col-lg-4 pt-1 pb-1 wow fadeIn" data-wow-delay="0.3s">
            <!-- About -->
            <h5 class="text-uppercase mb-3">
                <strong>ABOUT RESTAURANT</strong>
            </h5>

            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti
                atque corrupti.</p>

            <p class=""> Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias
                excepturi sint.</p>

            <div class="footer-socials">

                <!-- Facebook -->
                <a type="button" class="btn-floating rgba-white-slight">
                <i class="fab fa-facebook-f"></i>
                </a>
                <!-- Dribbble -->
                <a type="button" class="btn-floating rgba-white-slight">
                <i class="fab fa-dribbble"></i>
                </a>
                <!-- Twitter -->
                <a type="button" class="btn-floating rgba-white-slight">
                <i class="fab fa-twitter"></i>
                </a>
                <!-- Google + -->
                <a type="button" class="btn-floating rgba-white-slight">
                <i class="fab fa-google-plus-g"></i>
                </a>

            </div>
            </div>
            <!-- Grid column -->

            <hr class="w-100 clearfix d-md-none">

            <!-- Grid column -->
            <div class="col-xl-3 ml-xl-auto col-lg-4 col-md-6 pt-1 pb-1 wow fadeIn" data-wow-delay="0.3s">
            <!-- Search -->
            <h5 class="text-uppercase">
                <strong>Search something</strong>
            </h5>

            <ul class="footer-search list-unstyled">
                <li>
                <form class="search-form" role="search">
                    <div class="md-form waves-light waves-effect waves-light">
                    <input type="text" class="form-control white-text" placeholder="Search">
                    </div>
                </form>
                </li>
            </ul>

            <!-- Info -->
            <p>
                <i class="fas fa-home mr-3"></i> New York, NY 10012, US</p>
            <p>
                <i class="fas fa-envelope mr-3"></i> info@example.com</p>
            <p>
                <i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
            <p>
                <i class="fas fa-print mr-3"></i> + 01 234 567 89</p>

            </div>
            <!-- Grid column -->

            <hr class="w-100 clearfix d-md-none">

            <!-- Grid column -->
            <div class="text-center ml-xl-auto col-xl-3 col-lg-4 col-md-6 pt-1 pb-1 wow fadeIn" data-wow-delay="0.3s">

            <!-- Title -->
            <h5 class="text-uppercase mb-3">
                <strong>Opening hours</strong>
            </h5>

            <!-- Opening hours table -->
            <table class="table white-text">
                <tbody>
                <tr>
                    <td>Mon - Thu:</td>
                    <td>8am - 9pm</td>
                </tr>
                <tr>
                    <td>Fri - Sat:</td>
                    <td>8am - 1am</td>
                </tr>
                <tr>
                    <td>Sunday:</td>
                    <td>9am - 10pm</td>
                </tr>
                </tbody>
            </table>
            <a class="btn btn-rounded rgba-white-slight" data-toggle="modal" data-target="#modal-reservation">Book a
                table</a>

            </div>
            <!-- Grid column -->

        </div>
        <!-- Grid row -->

        </div>
        <!-- Footer Links -->

        <!-- Copyright -->
        <div class="footer-copyright py-3 text-center wow fadeIn" data-wow-delay="0.3s">
        <div class="container-fluid">
            © 2019 Copyright: <a href="https://mdbootstrap.com/education/bootstrap/" target="_blank"> MDBootstrap.com </a>
        </div>
        </div>
        <!-- Copyright -->

    </footer>
    <!-- Footer Links -->

    @include('template.partials.script')
    <!-- Custom scripts -->
    <script>

        // Animation init
        new WOW().init();

    </script>

</body>

</html>
