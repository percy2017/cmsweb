<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<title>{{ setting('site.title') }}</title>

<link href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" rel="stylesheet">
<link href="{{ asset('vendor/mdb/ecommerce/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('vendor/mdb/ecommerce/css/mdb.min.css') }}" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('vendor/whatsapp/floating-wpp.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/share/css/contact-buttons.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/up/css/floating-totop-button.css') }}">

@laravelPWA