@extends('layouts.app')

@section('content')

    <h1>Actualmente no estás conectado a ninguna red.</h1>

@endsection