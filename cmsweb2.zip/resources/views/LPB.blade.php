<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Material Design Bootstrap</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="vendor/mdb/lgp/css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="vendor/mdb/lgp/css/mdb.min.css" rel="stylesheet">
  <style>
    html,
    body,
    header,
    .view.jarallax {
      height: 100%;
      min-height: 100%;
    }
  </style>

  <link rel="stylesheet" type="text/css" href="vendor/whatsapp/floating-wpp.css">
   @laravelPWA
</head>

<body class="band-lp">

  <!-- Main Navigation -->
  <header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top scrolling-navbar">
      <div class="container">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
          aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav mr-auto smooth-scroll">
            <li class="nav-item">
              <a class="nav-link" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#about" data-offset="100">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#team" data-offset="100">Team</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#tour" data-offset="100">Tour</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#news" data-offset="100">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact" data-offset="100">Contact</a>
            </li>
          </ul>
          <!-- Social Icons -->
          <ul class="navbar-nav nav-flex-icons">
            <li class="nav-item">
              <a class="nav-link"><i class="fab fa-facebook-f"></i></a>
            </li>
            <li class="nav-item">
              <a class="nav-link"><i class="fab fa-twitter"></i></a>
            </li>
            <li class="nav-item">
              <a class="nav-link"><i class="fab fa-instagram"></i></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Intro Section -->
    <div id="home" class="view jarallax" data-jarallax='{"speed": 0.2}'>
      <div class="mask rgba-black-strong">
        <div class="container h-100 d-flex justify-content-center align-items-center">
          <div class="row smooth-scroll">
            <div class="col-md-12">
              <div class="text-center text-white">
                <div class="wow fadeInDown" data-wow-delay=".2s">
                  <h2 class="font-weight-bold display-3 mb-0">Band</h2>
                  <hr class="hr-light my-3 clearfix d-none d-md-block">
                  <h4 class="pt-2 pb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti consequuntur.</h4>
                </div>
                <a class="btn btn-pink-blue btn-rounded text-uppercase wow fadeInUp" data-wow-delay=".2s" href="#tour" data-offset="100">
                  <i class="far fa-calendar-alt mr-2"></i>
                  <span>get tickets now</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </header>
  <!-- Main Navigation -->

  <!-- Main content -->
  <main>

    <!-- First container -->
    <div class="container">

      <!-- Section: About -->
      <section id="about">

        <!-- Secion heading -->
        <h2 class="pink-text text-uppercase font-weight-bold mb-3 pt-4 mt-5 wow fadeIn" data-wow-delay=".2s">About us</h2>

        <hr class="mb-5">

        <!-- Grid row -->
        <div class="row mt-5 mb-2">

          <!-- Grid column -->
          <div class="col-lg-5 col-md-12 mb-2 mr-auto wow fadeIn" data-wow-delay=".4s">

            <!-- Image -->
            <img src="https://mdbootstrap.com/img/Others/landings/band.jpg" class="img-fluid z-depth-1-half" alt="My photo">

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-lg-6 col-md-12 mb-4 wow fadeIn" data-wow-delay=".4s">

            <!-- Description -->
            <p align="justify" class="grey-text-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo animi
              soluta ratione quisquam, dicta ab cupiditate iure eaque? Repellendus voluptatum, magni impedit delectus,
              beatae maxime temporibus maiores quibusdam.<br><br>Rem magnam ad perferendis iusto sint tempora ea
              voluptatibus iure, animi excepturi modi aut possimus in hic molestias repellendus illo ullam odit quia
              velit. Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br><br>Incidunt eligendi mollitia labore
              ipsum ex fugit explicabo saepe error neque beatae in, expedita eveniet quae aliquam assumenda
              voluptatibus! Iure dolorum, itaque. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta
              expedita, maiores omnis culpa voluptatem ipsum eius.</p>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </section>
      <!-- Section: About -->

      <!-- Section: Details -->
      <section>

        <!-- Section heading -->
        <h2 class="pink-text text-uppercase font-weight-bold mt-5 mb-2 wow fadeIn" data-wow-delay=".2s">Discography</h2>

        <hr class="mb-5">

        <!-- Grid row -->
        <div class="row text-center mb-4">

          <!-- Grid column -->
          <div class="col-lg-4 col-md-12 mb-5 wow fadeIn" data-wow-delay=".4s">

            <!-- Featured image -->
            <div class="view overlay z-depth-1 zoom">
              <img src="https://mdbootstrap.com/img/Others/landings/4a.jpg" class="img-fluid">
              <div class="mask rgba-white-slight"></div>
            </div>

            <!-- Excerpt -->
            <div class="card-block">
              <h4 class="font-weight-bold mt-4 mb-3">First title</h4>
              <a class="btn btn-pink-blue btn-rounded"><i class="fas fa-clone left"></i>buy now</a>
            </div>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-lg-4 col-md-6 mb-2 wow fadeIn" data-wow-delay=".4s">

            <!-- Featured image -->
            <div class="view overlay z-depth-1 zoom">
              <img src="https://mdbootstrap.com/img/Others/landings/1a.jpg" class="img-fluid">
              <div class="mask rgba-white-slight"></div>
            </div>

            <!-- Excerpt -->
            <div class="card-block">
              <h4 class="font-weight-bold mt-4 mb-3">Second title</h4>
              <a class="btn btn-pink-blue btn-rounded"><i class="fas fa-clone left"></i>buy now</a>
            </div>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-lg-4 col-md-6 mb-2 wow fadeIn" data-wow-delay=".4s">

            <!-- Featured image -->
            <div class="view overlay z-depth-1 zoom">
              <img src="https://mdbootstrap.com/img/Others/landings/3a.jpg" class="img-fluid">
              <div class="mask rgba-white-slight"></div>
            </div>

            <!-- Excerpt -->
            <div class="card-block">
              <h4 class="font-weight-bold mt-4 mb-3">Third title</h4>
              <a class="btn btn-pink-blue btn-rounded"><i class="fas fa-clone left"></i>buy now</a>
            </div>
          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </section>
      <!-- Section: Details -->

    </div>
    <!-- First container -->

    <!-- Streak -->
    <div class="streak streak-photo streak-md" style="background-image: url('https://mdbootstrap.com/img/Others/landings/concert.jpg');">
      <div class="mask flex-center rgba-black-strong">
        <div class="text-center white-text smooth-scroll wow fadeIn" data-wow-delay=".4s">
          <h2 class="h2-responsive font-weight-bold mb-3">Listen our music</h2>
          <a class="btn btn-white-red btn-rounded"><i class="fab  fa-youtube left"></i>you tube</a>
        </div>
      </div>
    </div>
    <!-- Streak -->

    <!-- Second container -->
    <div class="container">

      <!-- Section: Team v.2 -->
      <section id="team" class="team-section mt-5">

        <!-- Section heading -->
        <h2 class="pink-text text-uppercase font-weight-bold pt-4 mb-2 wow fadeIn" data-wow-delay=".2s">Our team</h2>

        <hr class="mb-5">

        <div class="row text-center">

          <!-- Grid column -->
          <div class="col-md-4 mb-4 wow fadeIn" data-wow-delay=".4s">

            <div class="avatar mx-auto mb-3">
              <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(9).jpg" class="img-fluid z-depth-1-half">
            </div>
            <h4 class="font-weight-bold">John Doe</h4>
            <h5 class="mb-3">lead vocals, guitar</h5>

            <!-- Facebook -->
            <a class="p-2 m-2 fa-lg fb-ic"><i class="fab fa-facebook-f"> </i></a>
            <!-- Youtube -->
            <a class="p-2 m-2 fa-lg yt-ic"><i class="fab  fa-youtube"> </i></a>
            <!-- Instagram -->
            <a class="p-2 m-2 fa-lg ins-ic"><i class="fab fa-instagram"> </i></a>

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-4 mb-4 wow fadeIn" data-wow-delay=".4s">

            <div class="avatar mx-auto mb-3">
              <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(8).jpg" class="img-fluid z-depth-1-half">
            </div>
            <h4 class="font-weight-bold">Chris Brown</h4>
            <h5 class="mb-3">backing vocals, percussion</h5>

            <!-- Google + -->
            <a class="p-2 m-2 fa-lg gplus-ic"><i class="fab fa-google-plus-g"> </i></a>
            <!-- Facebook -->
            <a class="p-2 m-2 fa-lg fb-ic"><i class="fab fa-facebook-f"> </i></a>
            <!-- Youtube -->
            <a class="p-2 m-2 fa-lg yt-ic"><i class="fab  fa-youtube"> </i></a>

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-4 mb-4 wow fadeIn" data-wow-delay=".4s">

            <div class="avatar mx-auto mb-3">
              <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(5).jpg" class="img-fluid z-depth-1-half">
            </div>
            <h4 class="font-weight-bold">Maria Kate</h4>
            <h5 class="mb-3">lead vocals, piano</h5>

            <!-- Twitter -->
            <a class="p-2 m-2 fa-lg tw-ic"><i class="fab fa-twitter"> </i></a>
            <!-- Instagram -->
            <a class="p-2 m-2 fa-lg ins-ic"><i class="fab fa-instagram"> </i></a>
            <!-- Youtube -->
            <a class="p-2 m-2 fa-lg yt-ic"><i class="fab  fa-youtube"> </i></a>

          </div>
          <!-- Grid column -->

        </div>

      </section>
      <!-- Section: Team v.2 -->

    </div>
    <!-- Second container -->

    <!-- Third container -->
    <div class="container-fluid mt-5 pb-4 grey-background">

      <!-- Tour section -->
      <div id="tour" class="container">

        <!-- Section heading -->
        <h2 class="pink-text text-uppercase font-weight-bold pt-5 mb-2 mt-3 wow fadeIn" data-wow-delay=".2s">Tour dates</h2>

        <hr class="mb-5">

        <div class="table-responsive">
          <table class="table wow fadeIn" data-wow-delay=".4s">
            <thead>
              <tr>
                <th>Date</th>
                <th>Country</th>
                <th>Place</th>
                <th>
                  <div class="pl-4">Tickets
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">Fri 31 Mar</th>
                <td>Poland, Warsaw</td>
                <td>National Stadium</td>
                <td><a class="btn btn-info btn-rounded btn-sm">buy now</a></td>
              </tr>
              <tr>
                <th scope="row">Mon 02 Apr</th>
                <td>France, Paris</td>
                <td>Olimpic Stadium</td>
                <td><a class="btn btn-info btn-rounded btn-sm">buy now</a></td>
              </tr>
              <tr>
                <th scope="row">Tue 07 May</th>
                <td>USA, New York</td>
                <td>National Stadium</td>
                <td><a class="btn btn-danger btn-rounded btn-sm">sold out</a></td>
              </tr>
              <tr>
                <th scope="row">Fri 10 May</th>
                <td>Germany, Berlin</td>
                <td>National Stadium</td>
                <td><a class="btn btn-info btn-rounded btn-sm">buy now</a></td>
              </tr>
              <tr>
                <th scope="row">Mon 02 Apr</th>
                <td>Italy, Milan</td>
                <td>Olimpic Stadium</td>
                <td><a class="btn btn-info btn-rounded btn-sm">buy now</a></td>
              </tr>
              <tr>
                <th scope="row">Sun 16 Jun</th>
                <td>USA, Los Angeles</td>
                <td>National Stadium</td>
                <td><a class="btn btn-danger btn-rounded btn-sm">sold out</a></td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>

    </div>
    <!-- Third container -->

    <!-- Fourth container -->
    <div class="container">

      <!-- Section: News -->
      <section id="news" class="mt-5 mb-4">

        <h2 class="pink-text text-uppercase font-weight-bold mb-2 pt-4 wow fadeIn" data-wow-delay=".2s">News & updates</h2>

        <hr class="mb-5">

        <!-- Section: Design -->
        <div class="text-center mt-3 text-lg-left">

          <!-- Grid row -->
          <div class="row pt-1 pb-4 wow fadeIn" data-wow-delay=".4s">

            <!-- Grid column -->
            <div class="col-lg-4 mb-md-0 mb-4">

              <!-- Image -->
              <div class="view overlay z-depth-1">
                <img src="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20%2820%29.jpg" class="img-fluid"
                  alt="Post Image">
                <div class="mask rgba-white-slight"></div>
              </div>

            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-lg-7 ml-lg-4">

              <!-- Excerpt -->
              <h5 class="text-uppercase mb-4"><a href="#!" class="text-muted grey-text-3 font-weight-bold">| 23 MAY
                  2017</a></h5>
              <h4 class="text-uppercase mb-4"><a href="#!" class="black-text-2 font-weight-bold pb-3">This is title of
                  the news </a></h4>
              <p class="grey-text-3 font-thin" align="justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                cupidatat non proident.</p>

            </div>
            <!-- Grid column -->

          </div>
          <!-- Grid row -->

          <hr class=" mb-4">

          <!-- Second row -->
          <div class="row pb-4 pt-3 wow fadeIn" data-wow-delay=".4s">

            <!-- Grid column -->
            <div class="col-lg-4 mb-md-0 mb-4">

              <!-- Image -->
              <div class="view overlay z-depth-1">
                <img src="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20%2811%29.jpeg" class="img-fluid z-depth-1-half"
                  alt="Post Image">
                <div class="mask rgba-white-slight"></div>
              </div>
              <!-- Image -->

            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-lg-7 ml-lg-4">

              <!-- Excerpt -->
              <h5 class="text-uppercase mb-4"><a href="#!" class="text-muted grey-text-3 font-weight-bold">| 23 MAY
                  2017</a></h5>
              <h4 class="text-uppercase mb-4"><a href="#!" class="black-text-2 font-weight-bold pb-3">This is title of
                  the news</a></h4>
              <p class="grey-text-3 font-thin" align="justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                cupidatat non proident.</p>
              <!-- Excerpt -->

            </div>
            <!-- Grid column -->

          </div>
          <!-- Second row -->

          <hr class=" mb-4">

          <!-- Third row -->
          <div class="row mb-5 pt-3 wow fadeIn" data-wow-delay=".4s">

            <!-- Grid column -->
            <div class="col-lg-4 mb-md-0 mb-4">

              <!-- Image -->
              <div class="view overlay z-depth-1">
                <img src="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20%2810%29.jpg" class="img-fluid z-depth-1-half"
                  alt="Post Image">
                <div class="mask rgba-white-slight"></div>
              </div>
              <!-- Image -->

            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-lg-7 ml-lg-4 mb-5">

              <!-- Excerpt -->
              <h5 class="text-uppercase mb-4"><a href="#!" class="text-muted grey-text-3 font-weight-bold">| 31 JUN
                  2017</a></h5>
              <h4 class="text-uppercase mb-4"><a href="#!" class="black-text-2 font-weight-bold pb-3">This is title of
                  the news</a></h4>
              <p class="grey-text-3 font-thin" align="justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
                nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                cupidatat non proident.</p>
              <!-- Excerpt -->

            </div>
            <!-- Grid column -->

          </div>
          <!-- Third row -->

        </div>
        <!-- Section: Design -->

      </section>
      <!-- Section: News -->

    </div>
    <!-- Fourth container -->

    <!-- Contact form -->
    <div style="background-image:url('https://mdbootstrap.com/img/Others/landings/music1.jpg')">
      <div class="mask flex-center rgba-black-strong">
        <div id="contact" class="container">

          <!-- Section: Contact v.2 -->
          <section class="contact-section mb-5">

            <!-- Grid row -->
            <div class="row mt-5">
              <div class="col-md-12 ">
                <h2 class="pink-text text-uppercase font-weight-bold pt-4 mb-5 wow fadeIn" data-wow-delay=".2s">Contact us</h2>
              </div>
            </div>
            <!-- Grid row -->

            <!-- Second row -->
            <div class="row wow fadeIn" data-wow-delay=".4s">

              <!-- Grid column -->
              <div class="col-md-8">
                <form>
                  <!-- Grid row -->
                  <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-6">
                      <div class="md-form">
                        <input type="text" id="form41" class="form-control text-white">
                        <label for="form41">Your name</label>
                      </div>
                    </div>

                    <!-- Grid column -->
                    <div class="col-md-6">
                      <div class="md-form">
                        <input type="text" id="form52" class="form-control text-white">
                        <label for="form52">Your email</label>
                      </div>
                    </div>
                  </div>
                  <!-- Grid row -->

                  <!-- Second row -->
                  <div class="row">
                    <div class="col-md-12">
                      <div class="md-form">
                        <input type="text" id="form51" class="form-control text-white">
                        <label for="form51">Subject</label>
                      </div>
                    </div>
                  </div>
                  <!-- Second row -->

                  <!-- Third row -->
                  <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-12">

                      <div class="md-form">
                        <textarea type="text" id="form76" class="md-textarea form-control text-white" rows="3"></textarea>
                        <label for="form76">Your message</label>
                      </div>

                    </div>
                  </div>
                  <!-- Third row -->
                </form>

                <div class="text-center text-md-left mt-4 mb-4">
                  <a class="btn btn-pink-blue btn-rounded"></i>send</a>
                </div>
              </div>
              <!-- Grid column -->

              <!-- Grid column -->
              <div class="col-md-4">
                <ul class="text-center list-unstyled">
                  <li><i class="fas fa-map-marker-alt pink-text fa-2x"></i>
                    <div class="white-text">
                      <p>New York, NY 10012, USA</p>
                    </div>
                  </li>

                  <li><i class="fas fa-phone pink-text fa-2x"></i>
                    <div class="white-text">
                      <p>+ 01 234 567 89</p>
                    </div>
                  </li>

                  <li><i class="fas fa-envelope pink-text fa-2x"></i>
                    <div class="white-text">
                      <p>contact@mdbootstrap.com</p>
                    </div>
                  </li>
                </ul>
              </div>
              <!-- Grid column -->
            </div>
            <!-- Second row -->

          </section>
          <!-- Section: Contact v.2 -->

        </div>
      </div>
    </div>
    <!-- Contact form -->

    <!-- Fifth container -->
    <div class="container">

      <!-- Section: Video -->
      <section>

        <!-- Grid row -->
        <div class="row mt-5">
          <div class="col-md-12">
            <h2 class="pink-text text-uppercase font-weight-bold pt-4 mb-2 wow fadeIn" data-wow-delay=".2s">Videos</h2>
            <hr class="mb-5">
          </div>
        </div>
        <!-- Grid row -->

        <!-- Second row -->
        <div class="row pb-4 wow fadeIn" data-wow-delay=".4s">

          <!-- Grid column -->
          <div class="col-md-6 mb-1 mt-1">
            <div class="view overlay">
              <img src="https://mdbootstrap.com/img/Photos/Others/video2.jpg" alt="video" class="img-fluid z-depth-1-half">
              <a href="https://www.youtube.com/embed/2fuuBLkDBcE" target="_blank">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 mb-1 mt-1">
            <div class="view overlay">
              <img src="https://mdbootstrap.com/img/Photos/Others/video1.jpg" class="img-fluid z-depth-1-half" alt="video">
              <a href="https://www.youtube.com/embed/FyF3GQoj2ho" target="_blank">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
          </div>
          <!-- Grid column -->

        </div>
        <!-- Second row -->

      </section>
      <!-- Section: Video -->

      <!-- Section: Gallery -->
      <section id="portfolio">

        <h2 class="pink-text text-uppercase font-weight-bold mb-2 pt-5 wow fadeIn" data-wow-delay=".2s">Photos</h2>

        <hr class="mb-5">

        <!-- Grid row -->
        <div class="row wow fadeIn" data-wow-delay=".4s">

          <!-- Grid column -->
          <div class="col-md-12">

            <div id="mdb-lightbox-ui"></div>

            <!-- Full width lightbox -->
            <div class="mdb-lightbox">

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(10).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(10).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(21).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(21).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(11).jpeg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(11).jpg" class="img-fluid z-depth-1-half">
                </a>

              </figure>
              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(22).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(22).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(19).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(19).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(22).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(22).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(20).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(20).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

              <figure class="col-md-3">
                <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(13).jpg" data-size="1600x1067">
                  <img src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(13).jpg" class="img-fluid z-depth-1-half">
                </a>
              </figure>

            </div>
            <!-- Full width lightbox -->

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </section>
      <!-- Section: Gallery -->

      <!-- Pagination dark -->
      <nav class="d-flex justify-content-center pt-5 pb-1 wow fadeIn" data-wow-delay=".4s">
        <ul class="pagination pg-dark">
          <!-- Arrow left -->
          <li class="page-item">
            <a class="page-link" aria-label="Previous">
              <span aria-hidden="true">&laquo;</span>
              <span class="sr-only">Previous</span>
            </a>
          </li>

          <!-- Numbers -->
          <li class="page-item active"><a class="page-link">1</a></li>
          <li class="page-item"><a class="page-link">2</a></li>
          <li class="page-item"><a class="page-link">3</a></li>
          <li class="page-item"><a class="page-link">4</a></li>
          <li class="page-item"><a class="page-link">5</a></li>

          <!-- Arrow right -->
          <li class="page-item">
            <a class="page-link" aria-label="Next">
              <span aria-hidden="true">&raquo;</span>
              <span class="sr-only">Next</span>
            </a>
          </li>
        </ul>
      </nav>
      <!-- Pagination dark -->

    </div>
    <!-- Fifth container -->

  </main>
  <!-- Main content -->

  <!-- Footer -->
  <footer class="page-footer text-center text-md-left mt-4 pt-4">

    <!-- Footer Links -->
    <div class="container mb-4">

      <!-- Grid row -->
      <div class="row text-center">

        <!-- Grid column -->
        <div class="col-md-12 mt-1 mb-1 wow fadeIn" data-wow-delay="0.3s">

          <div class="footer-socials mt-1 mb-2">

            <!-- Facebook -->
            <a type="button" class="btn-floating btn-blue-pink"><i class="fab fa-facebook-f"></i></a>
            <!-- Twitter -->
            <a type="button" class="btn-floating btn-blue-pink"><i class="fab fa-twitter"></i></a>
            <!-- Google + -->
            <a type="button" class="btn-floating btn-blue-pink"><i class="fab fa-google-plus-g"></i></a>
            <!-- Youtube -->
            <a type="button" class="btn-floating  btn-blue-pink"><i class="fab  fa-youtube"></i></a>
            <!-- Instagram -->
            <a type="button" class="btn-floating  btn-blue-pink"><i class="fab fa-instagram"></i></a>

          </div>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright py-3 text-center">
      <div class="container-fluid">
        © 2019 Copyright: <a href="https://mdbootstrap.com/education/bootstrap/" target="_blank"> MDBootstrap.com </a>
      </div>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->

<div id="myWP"></div>
  <!--  SCRIPTS  -->
  <!--  JQuery  -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/jquery-3.4.1.min.js"></script>
  <!--  Bootstrap tooltips  -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/popper.min.js"></script>
  <!--  Bootstrap core JavaScript  -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/bootstrap.min.js"></script>
  <!--  MDB core JavaScript  -->
  <script type="text/javascript" src="vendor/mdb/lgp/js/mdb.min.js"></script>

  <script src="vendor/whatsapp/floating-wpp.js"></script>
  <!-- Custom scripts -->
  <script>

    // Animation init
    new WOW().init();

    // MDB Lightbox Init
    $(function () {
      $("#mdb-lightbox-ui").load("vendor/mdb/lgp/mdb-addons/mdb-lightbox-ui.html");
    });


    $('#myWP').floatingWhatsApp({
      phone: '{{ setting('whatsapp.phone') }}',
      popupMessage: '{{ setting('whatsapp.popupMessage') }}',
      message: '{{ setting('whatsapp.message') }}',
      showPopup: true,
      showOnIE: true,
      headerTitle: '{{ setting('whatsapp.headerTitle') }}',
      headerColor: '{{ setting('whatsapp.color') }}',
      backgroundColor: '{{ setting('whatsapp.color') }}',
      buttonImage: '<img src="{{ asset('storage/'.setting('whatsapp.buttonImage') ) }}" />',
      position: '{{ setting('whatsapp.position') }}',
      autoOpenTimeout: {{ setting('whatsapp.autoOpenTimeout') }},
      size: '{{ setting('whatsapp.size') }}'
    });

  </script>

</body>

</html>
